package com.betaplan.klea.exam.services;

import com.betaplan.klea.exam.models.Movie;
import com.betaplan.klea.exam.models.Rate;
import com.betaplan.klea.exam.models.User;
import com.betaplan.klea.exam.repositories.MovieRepository;
import com.betaplan.klea.exam.repositories.RateRepository;
import com.betaplan.klea.exam.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RateService {
    @Autowired
    private RateRepository rateRepository;
    @Autowired
    private MovieRepository movieRepository;
    @Autowired
    private UserRepository userRepository;

    public void createRate(Long movieId,Long userId,Integer rate1){
        Movie movie= movieRepository.findMovieById(movieId);
        User user=userRepository.findUserById(userId);
        Rate rate=new Rate(movie,user,rate1);
        rateRepository.save(rate);
    }

//    public void createRate(Rate rate){
//
//        rateRepository.save(rate);
//    }
    public void deleteLike(Long likeId){
        rateRepository.deleteById(likeId);
    }

    public Rate findRate(Long movieId, Long userId){
        return rateRepository.findRateByMovie_IdAndRater_Id(movieId,userId);
    }


}
