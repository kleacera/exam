package com.betaplan.klea.exam.repositories;

import com.betaplan.klea.exam.models.Movie;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieRepository extends CrudRepository<Movie,Long> {
    Movie findMovieById(Long id);
    List<Movie> findAll();

}
