package com.betaplan.klea.exam.controllers;


import com.betaplan.klea.exam.models.Movie;
import com.betaplan.klea.exam.models.Rate;
import com.betaplan.klea.exam.models.User;
import com.betaplan.klea.exam.services.MovieService;
import com.betaplan.klea.exam.services.RateService;
import com.betaplan.klea.exam.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.List;

@Controller
public class MovieController {
    private final MovieService movieService;
    @Autowired
    private UserService userService;
    @Autowired
    private RateService rateService;

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/movies")
    public String showMovies(@ModelAttribute("rate") Movie movie, HttpSession session, Model model){
        Long userId = ((Long) session.getAttribute("userId"));
        if(userId==null){
            return "redirect:/";
        }else{
            User authenticatedUser = userService.findUserById(userId);
            model.addAttribute("user", authenticatedUser);
            model.addAttribute("movies", movieService.findAllMovies());
            return "movie/dashboard";
        }
    }
    @PostMapping("/movie/{id}/rate")
    public String ratePost(@ModelAttribute("rate") Rate rate1, @PathVariable("id")Long movieId, HttpSession session){
        Long userId = ((Long) session.getAttribute("userId"));
        if (userId == null) {
            return "redirect:/";
        } else {
//            User authenticatedUser = userService.findUserById(userId);
//            rate.setRater(authenticatedUser);
//            Movie movie = movieService.findMovie(movieId);
//            rate.setMovie(movie);
//            rateService.createRate(rate);
            rateService.createRate(movieId,userId,rate1.getRateNr());
            return "redirect:/movies";
        }
    }

    @GetMapping("/movie/new")
    public String viewCreateMovie(@ModelAttribute("movie") Movie movie, HttpSession session, Model model){
        Long userId = ((Long) session.getAttribute("userId"));
        if(userId==null){
            return "redirect:/";
        }else{
            User authenticatedUser = userService.findUserById(userId);
            model.addAttribute("user", authenticatedUser);
            return "movie/new";
        }
    }
    @PostMapping("/movie/create")
    public String createMovie(@Valid @ModelAttribute("movie")Movie movie, BindingResult result, HttpSession session){
        Long userId = ((Long) session.getAttribute("userId"));
        if (userId == null) {
            return "redirect:/";
        } else {
            if (result.hasErrors()) {
                return "movie/new";
            } else {
                User authenticatedUser = userService.findUserById(userId);
                movie.setCreator(authenticatedUser);
                movieService.createMovie(movie);
                return "redirect:/movies";
            }
        }
    }

    @GetMapping("/movie/{id}")
    public String viewMovie(@ModelAttribute("rate") Rate rate,Model model,@PathVariable("id")Long id,HttpSession session){
        Long userId = ((Long) session.getAttribute("userId"));
        if(userId==null){
            return "redirect:/";
        }else{
            Movie movie = movieService.findMovie(id);
            List<Rate> raters= movie.getRaters();
            model.addAttribute("movie", movie);
            model.addAttribute("userId",userId);
            model.addAttribute("raters",raters);
            return "movie/info";
        }
    }

    @GetMapping("/movie/{id}/edit")
    public String viewEditMovie(Model model,@PathVariable("id")Long movieId,HttpSession session){
        Long userId = ((Long) session.getAttribute("userId"));
        Movie movie= movieService.findMovie(movieId);
        if(userId==null){
            return "redirect:/";
        }else{
//            if(userId != movie.getCreator().getId()){
////                return "redirect:/movies";
//                return "movie/edit";
//            }
            model.addAttribute("movie",movie);
            return "movie/edit";
        }
    }
    @PutMapping("/movie/{id}/edit")
    public  String editMovie(@Valid @ModelAttribute("movie")Movie movie,BindingResult result,HttpSession session,@PathVariable("id")Long movieId) {
        Long userId = ((Long) session.getAttribute("userId"));
        Movie testMovie= movieService.findMovie(movieId);
        if (userId == null) {
            return "redirect:/";
        } else {
            if(!userId.equals(testMovie.getCreator().getId())){
                return "redirect:/movies";
            }
            if (result.hasErrors()) {
                return "movie/edit";
            } else {

                User authenticatedUser = userService.findUserById(userId);
                movie.setCreator(authenticatedUser);
                movieService.updateMovie(movie);
                return "redirect:/movies";
            }
        }
    }
    @DeleteMapping("/movie/{id}/delete")
    public String deleteMovie(@PathVariable("id")Long movieId,HttpSession session) {
        Long userId = ((Long) session.getAttribute("userId"));
        Movie movie = movieService.findMovie(movieId);
        if (userId == null) {
            return "redirect:/";
        } else {
            if(!userId.equals(movie.getCreator().getId())){
                return "redirect:/movies";
            }
            movieService.deleteMovie(movieId);
            return "redirect:/movies";
        }
    }

}
