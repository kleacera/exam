package com.betaplan.klea.exam.services;


import com.betaplan.klea.exam.models.Movie;
import com.betaplan.klea.exam.repositories.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieService {
    @Autowired
    private MovieRepository movieRepository;

    public void createMovie(Movie movie){
        movieRepository.save(movie);
    }
    public void updateMovie(Movie movie){
        movieRepository.save(movie);
    }
    public Movie findMovie(Long id){
        return movieRepository.findMovieById(id);
    }
    public List<Movie> findAllMovies(){
        return  movieRepository.findAll();
    }
//    public List<Movie> findMostLikedMovies(){
//        return movieRepository.findTopByOrderByRate();
//    }
//    public List<Movie> findNotPopularMovies(){
//        return  movieRepository.findTopByOrderByRateDesc();
//    }
    public void deleteMovie(Long id){
        movieRepository.deleteById(id);
    }

}

