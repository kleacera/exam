package com.betaplan.klea.exam.repositories;

import com.betaplan.klea.exam.models.Rate;
import org.springframework.data.repository.CrudRepository;

public interface RateRepository extends CrudRepository<Rate,Long> {

    Rate findRateByMovie_IdAndRater_Id(Long movieId, Long userId);

}
